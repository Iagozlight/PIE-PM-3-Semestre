package projeto.repositories;

import jakarta.persistence.EntityManager;
import projeto.models.ClientesRomaneio;

import java.util.List;

public class ClientesRomaneioRepository {

    private EntityManager em;

    public ClientesRomaneioRepository (EntityManager em){
        this.em = em;
    }

    public ClientesRomaneio findById(Long id){
        return em.find(ClientesRomaneio.class, id);
    }

    public void create(ClientesRomaneio clientesRomaneio) {
        em.getTransaction().begin();
        em.persist(clientesRomaneio);
        em.getTransaction().commit();
    }

    public void update(ClientesRomaneio clientesRomaneio) {
        em.getTransaction().begin();
        em.merge(clientesRomaneio);
        em.getTransaction().commit();
    }

    public void delete(ClientesRomaneio clientesRomaneio) {
        em.getTransaction().begin();
        em.remove(em.contains(clientesRomaneio) ? clientesRomaneio : em.merge(clientesRomaneio));
        em.getTransaction().commit();
    }

    public List<ClientesRomaneio> findAll() {
        return em.createQuery("select c from ClientesRomaneio c", ClientesRomaneio.class).getResultList();
    }

    public List<ClientesRomaneio> findByName(String prefixo) {
        return em.createQuery("select c from ClientesRomaneio c where c.nome_cliente like :prefixo", ClientesRomaneio.class)
                .setParameter("prefixo", prefixo + "%")
                .getResultList();
    }

    public List<ClientesRomaneio> findSemRomaneio() {
        return em.createQuery("select c from ClientesRomaneio c where c.romaneio is null",
                ClientesRomaneio.class).getResultList();
    }

    public ClientesRomaneio findByCpf(String cpf) {
        List<ClientesRomaneio> clientes = em.createQuery("select c from ClientesRomaneio c where c.cpf = :cpf", ClientesRomaneio.class)
                .setParameter("cpf", cpf)
                .getResultList();
        if (clientes.isEmpty()) {
            return null;
        }
        return clientes.get(0);
    }

    public ClientesRomaneio findByTelefone(String telefone) {
        List<ClientesRomaneio> clientes = em.createQuery(
                        "select c from ClientesRomaneio c where c.telefone = :telefone",
                        ClientesRomaneio.class)
                .setParameter("telefone", telefone)
                .getResultList();
        if (clientes.isEmpty()) {
            return null;
        }
        return clientes.get(0);
    }

    public boolean existsByCpf(String cpf) {
        return findByCpf(cpf) != null;
    }

    public boolean existsByTelefone(String telefone) {
        return findByTelefone(telefone) != null;
    }
}
